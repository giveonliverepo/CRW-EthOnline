class ImageConstant {
  static String imgHome = 'assets/images/img_home.png';

  static String imgTimelight = 'assets/images/img_timelight.svg';

  static String imgContentblock1 = 'assets/images/img_contentblock_1.png';

  static String imgContentblock2 = 'assets/images/img_contentblock_2.png';

  static String imgImage8 = 'assets/images/img_image8.png';

  static String imgRectangle309 = 'assets/images/img_rectangle30_9.png';

  static String imgRectangle308 = 'assets/images/img_rectangle30_8.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgImage6 = 'assets/images/img_image6.png';

  static String imgContentblock80X80 =
      'assets/images/img_contentblock_80X80.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgRectangle307 = 'assets/images/img_rectangle30_7.png';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgWallet = 'assets/images/img_wallet.png';

  static String imgContentblock50X50 =
      'assets/images/img_contentblock_50X50.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgMusic = 'assets/images/img_music.svg';

  static String imgImage5 = 'assets/images/img_image5.png';

  static String imgImage4225X375 = 'assets/images/img_image4_225X375.png';

  static String imgWallet27X27 = 'assets/images/img_wallet_27X27.png';

  static String imgHome28X28 = 'assets/images/img_home_28X28.png';

  static String imgRightside11X66 = 'assets/images/img_rightside_11X66.svg';

  static String imgLocation17X15 = 'assets/images/img_location_17X15.svg';

  static String imgArrowdownGray900 =
      'assets/images/img_arrowdown_gray_900.svg';

  static String imgRectangle30110X110 =
      'assets/images/img_rectangle30_110X110.png';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgEmailsend = 'assets/images/img_emailsend.png';

  static String imgRightside = 'assets/images/img_rightside.svg';

  static String imgPlus26X21 = 'assets/images/img_plus_26X21.png';

  static String imgRectangle305 = 'assets/images/img_rectangle30_5.png';

  static String imgStar = 'assets/images/img_star.png';

  static String imgArrowdownWhiteA700 =
      'assets/images/img_arrowdown_white_A700.svg';

  static String imgNotchBlack900 = 'assets/images/img_notch_black_900.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgRectangle306 = 'assets/images/img_rectangle30_6.png';

  static String imgUser30X30 = 'assets/images/img_user_30X30.svg';

  static String imgImage3821X375 = 'assets/images/img_image3_821X375.png';

  static String imgNotch = 'assets/images/img_notch.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgIosstatusbar = 'assets/images/img_iosstatusbar.svg';

  static String imgRectangle3010 = 'assets/images/img_rectangle30_10.png';

  static String imgCoins = 'assets/images/img_coins.png';

  static String imgRectangle304 = 'assets/images/img_rectangle30_4.png';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgContentblock3 = 'assets/images/img_contentblock_3.png';

  static String imgRectangle30 = 'assets/images/img_rectangle30.png';

  static String imgAsset461 = 'assets/images/img_asset461.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgContentblock225X375 =
      'assets/images/img_contentblock_225X375.png';

  static String imgRectangle302 = 'assets/images/img_rectangle30_2.png';

  static String imgImage3 = 'assets/images/img_image3.png';

  static String imgBackgroundhome812X375 =
      'assets/images/img_backgroundhome_812X375.png';

  static String imgSignal11X66 = 'assets/images/img_signal_11X66.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgLocation14X10 = 'assets/images/img_location_14X10.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgImage4233X375 = 'assets/images/img_image4_233X375.png';

  static String imgContentblock5 = 'assets/images/img_contentblock_5.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgImage9 = 'assets/images/img_image9.png';

  static String imgContentblock4 = 'assets/images/img_contentblock_4.png';

  static String imgHeart = 'assets/images/img_heart.png';

  static String imgRectangle303 = 'assets/images/img_rectangle30_3.png';

  static String imgArrow = 'assets/images/img_arrow.png';

  static String imgBackgroundhome1 = 'assets/images/img_backgroundhome_1.png';

  static String imgRectangle301 = 'assets/images/img_rectangle30_1.png';

  static String imgBackgroundhome = 'assets/images/img_backgroundhome.png';

  static String img941 = 'assets/images/img_941.svg';

  static String imgContentblock = 'assets/images/img_contentblock.png';

  static String imgImage4 = 'assets/images/img_image4.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
