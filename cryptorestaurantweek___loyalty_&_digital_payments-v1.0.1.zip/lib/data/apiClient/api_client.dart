import 'package:cryptorestaurantweek___loyalty__digital_payments/core/app_export.dart';

class ApiClient extends GetConnect {}
