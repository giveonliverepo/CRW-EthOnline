import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/homepage_one_screen/models/homepage_one_model.dart';

class HomepageOneController extends GetxController {
  Rx<HomepageOneModel> homepageOneModelObj = HomepageOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
