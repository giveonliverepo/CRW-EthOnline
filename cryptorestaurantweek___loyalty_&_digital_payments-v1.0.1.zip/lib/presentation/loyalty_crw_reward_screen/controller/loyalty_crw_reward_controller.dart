import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/loyalty_crw_reward_screen/models/loyalty_crw_reward_model.dart';

class LoyaltyCrwRewardController extends GetxController {
  Rx<LoyaltyCrwRewardModel> loyaltyCrwRewardModelObj =
      LoyaltyCrwRewardModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
