class LoyaltyCrwRewardModel {}
