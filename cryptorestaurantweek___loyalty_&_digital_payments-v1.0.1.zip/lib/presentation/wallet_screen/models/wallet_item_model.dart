class WalletItemModel {}
