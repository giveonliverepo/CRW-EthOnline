import 'package:get/get.dart';
import 'wallet_item_model.dart';

class WalletModel {
  RxList<WalletItemModel> walletItemList = RxList.filled(5, WalletItemModel());
}
