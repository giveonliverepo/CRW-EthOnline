import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/wallet_screen/models/wallet_model.dart';

class WalletController extends GetxController {
  Rx<WalletModel> walletModelObj = WalletModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
