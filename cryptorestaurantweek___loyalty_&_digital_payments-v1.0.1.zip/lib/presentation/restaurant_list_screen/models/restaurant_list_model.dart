class RestaurantListModel {}
