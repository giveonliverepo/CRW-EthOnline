import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/reservation_request_screen/models/reservation_request_model.dart';

class ReservationRequestController extends GetxController {
  Rx<ReservationRequestModel> reservationRequestModelObj =
      ReservationRequestModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
