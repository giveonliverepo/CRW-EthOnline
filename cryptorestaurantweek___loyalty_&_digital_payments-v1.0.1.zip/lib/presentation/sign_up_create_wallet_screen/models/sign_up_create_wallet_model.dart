class SignUpCreateWalletModel {}
