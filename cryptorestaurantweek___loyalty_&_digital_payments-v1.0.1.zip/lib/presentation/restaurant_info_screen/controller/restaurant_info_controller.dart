import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/restaurant_info_screen/models/restaurant_info_model.dart';

class RestaurantInfoController extends GetxController {
  Rx<RestaurantInfoModel> restaurantInfoModelObj = RestaurantInfoModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
