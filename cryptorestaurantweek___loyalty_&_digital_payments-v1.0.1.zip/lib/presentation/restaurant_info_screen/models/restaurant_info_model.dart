class RestaurantInfoModel {}
