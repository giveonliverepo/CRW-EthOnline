import 'package:get/get.dart';
import 'listplus_item_model.dart';

class WalletSellingBuyingModel {
  RxList<ListplusItemModel> listplusItemList =
      RxList.filled(3, ListplusItemModel());
}
