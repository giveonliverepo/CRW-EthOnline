import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/pay_screen/models/pay_model.dart';

class PayController extends GetxController {
  Rx<PayModel> payModelObj = PayModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
