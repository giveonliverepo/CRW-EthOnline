class BookingConfirmationOneModel {}
