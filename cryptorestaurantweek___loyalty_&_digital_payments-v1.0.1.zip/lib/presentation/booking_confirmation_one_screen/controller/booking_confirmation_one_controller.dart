import '/core/app_export.dart';
import 'package:cryptorestaurantweek___loyalty__digital_payments/presentation/booking_confirmation_one_screen/models/booking_confirmation_one_model.dart';

class BookingConfirmationOneController extends GetxController {
  Rx<BookingConfirmationOneModel> bookingConfirmationOneModelObj =
      BookingConfirmationOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
